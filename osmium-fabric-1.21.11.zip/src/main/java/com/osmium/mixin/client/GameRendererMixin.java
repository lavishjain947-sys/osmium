package com.osmium.mixin.client;

import com.osmium.OsmiumConfig;
import com.osmium.render.DynamicResolutionController;
import com.osmium.render.HierarchicalZCuller;
import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.GameRenderer;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.client.util.Window;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import com.osmium.render.TemporalUpscaler;
import com.osmium.render.VariableRateShading;
import org.joml.Matrix4f;

@Mixin(GameRenderer.class)
public class GameRendererMixin {

    @Inject(method = "renderWorld", at = @At("HEAD"), require = 1)
    private void osmium$beforeWorldRender(RenderTickCounter tickCounter,
            CallbackInfo ci) {
        OsmiumConfig cfg = OsmiumConfig.get();
        if (cfg == null || !cfg.enabled) return;

        if (cfg.dynamicResolutionEnabled) {
            DynamicResolutionController.tick(cfg);
        }

        Window window = MinecraftClient.getInstance().getWindow();
        if (window != null) {
            VariableRateShading.beginFrame(window.getFramebufferWidth(), window.getFramebufferHeight());
        }

        Matrix4f viewProj = new Matrix4f(RenderSystem.getProjectionMatrix());
        viewProj.mul(RenderSystem.getModelViewMatrix());
        TemporalUpscaler.updateMatrices(viewProj);

        float scale = DynamicResolutionController.getScale();
        if (scale < 0.999f) {
            if (window != null) {
                int w = Math.max(1, (int) (window.getFramebufferWidth() * scale));
                int h = Math.max(1, (int) (window.getFramebufferHeight() * scale));
                RenderSystem.viewport(0, 0, w, h);
            }
        }
    }

    @Inject(method = "renderWorld", at = @At("RETURN"), require = 1)
    private void osmium$afterWorldRender(RenderTickCounter tickCounter,
            CallbackInfo ci) {
        VariableRateShading.endFrame();

        Window window = MinecraftClient.getInstance().getWindow();
        if (window != null) {
            RenderSystem.viewport(0, 0,
                    window.getFramebufferWidth(), window.getFramebufferHeight());
            float scale = DynamicResolutionController.getScale();
            if (scale < 0.999f && MinecraftClient.getInstance().getFramebuffer() != null) {
                int w = Math.max(1, (int) (window.getFramebufferWidth() * scale));
                int h = Math.max(1, (int) (window.getFramebufferHeight() * scale));
                DynamicResolutionController.upscaleIfNeeded(
                        MinecraftClient.getInstance().getFramebuffer().fbo,
                        w, h, window.getFramebufferWidth(), window.getFramebufferHeight()
                );
            }
        }
    }
}
